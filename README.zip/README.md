﻿#  Nodejs whatapp-message-api

**This is simple API for sending whatsapp message**

You will need to have a business account in meta with testing phone number before sending messages to whatsapp



```Environment Variables```
- WHATSAPP_BUSINESS_ACCOUNT_ID=""
- WHATSAPP_PHONE_NUMBER_ID=""
- WHATSAPP_TESTING_PHONE_NUMBER=""
- VERSION="v19.0"
- WHATSAPP_ACCESS_TOKEN=""
